"""
Chain-of-Thought (CoT) validation tools package.
"""

__version__ = "2.0.0"